package model;

import java.util.*;

public class Mao {
	
	ArrayList<Carta> lista_cartas;
	
	public Mao() {	//construtor				
		this.lista_cartas = new ArrayList<>();  // cria uma lista para as cartas na mao						//mao nao passou e não é 21 em valor ainda
	}
	
	public void addCarta(Carta carta) { 
		lista_cartas.add(carta);		
	}
	
	public int calculaValorMao() {
		int total = 0;
		for(Carta carta : lista_cartas) {
			total += carta.getValor();
		}
		return total;
	}
	
	public void limpaMao() {
		lista_cartas.clear();
	}

	public ArrayList<Carta> getLista_cartas() {
		return lista_cartas;
	}
	
	
}
