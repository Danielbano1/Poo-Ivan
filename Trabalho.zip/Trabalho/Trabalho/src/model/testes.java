package model;

import java.util.*;

public class testes {
	public static void main(String[] args) {
		boolean retorno;
		int aposta;
		Scanner s = null;

		// Jogo comeca
		Partida partida = new Partida();

		// dinheiro
		System.out.printf("Dinheiro: %d\n", partida.getDinheiro());

		// Aposta
		s = new Scanner(System.in);
		System.out.println("Informe sua aposta [50, 100, 200, 500, 1000]: ");
		aposta = s.nextInt();
		if (partida.checkAposta(aposta) == false)
			System.out.println("Dinheiro insuficiente");

		System.out.println("Informe sua aposta [50, 100, 200, 500, 1000]: ");
		aposta = s.nextInt();
		retorno = partida.checkAposta(aposta);

		if (partida.validaAposta() == false) {
			System.out.println("Aposta abaixo de 50");
			System.exit(1);
		}

		System.out.println("Voce apostou " + partida.getMaoJogador().getAposta() + "$\n");

		// dinheiro
		System.out.printf("Dinheiro: %d\n\n", partida.getDinheiro());

		// Distribui as cartas
		partida.distribuiCarta();

		// Mostra turno
		System.out.printf("Turno: %d\n", partida.getTurnos());

		// Mostra a mao
		ArrayList<Carta> lista_cartas = partida.getMao().getLista_cartas();
		System.out.println("Suas cartas sao:\n");
		for (Carta carta : lista_cartas) {
			System.out.printf("valor: %d, naipe: %s\n", carta.getValor(), carta.getNaipe());
		}

		// Menu hit e stand
		System.out.println("Hit[1], Stand[2]. Surrender[3], Split[4]");
		aposta = s.nextInt();
		if (aposta == 3) {
			partida.rendicao();
			retorno = true;
		} else {
			retorno = false;
			while (aposta == 1) {
				if (aposta == 1) {
					partida.hit();

					// Mostra a mao
					lista_cartas = partida.getMao().getLista_cartas();
					System.out.println("Suas cartas sao:\n");
					for (Carta carta : lista_cartas) {
						System.out.printf("valor: %d, naipe: %s\n", carta.getValor(), carta.getNaipe());
					}
					// Menu hit e stand
					System.out.println("Hit[1], Stand[2]");
					aposta = s.nextInt();
				}
			}
		}
		partida.terminaTurno();

		// Dealer Joga
		System.out.printf("Turno: %d\n", partida.getTurnos());

		partida.jogaDealer();

		System.out.printf("pontuacao do Dealer: %d\n", partida.getMao().calculaValorMao());
		
		if(retorno == true)
			System.out.println("Jogador desistiu, 50% da aposta retorna para ele\n");
		// Mostra resultado final
		System.out.println(partida.checkStatusPartida());

		// dinheiro
		System.out.printf("Dinheiro: %d\n", partida.getDinheiro());

	}

}
