package model;

import java.util.*;

public class MaoJogador extends Mao {
	
	private int aposta;
	
	public MaoJogador() { 
		this.lista_cartas = new ArrayList<>();
		aposta = 0;
		
	}
	
	public void aumentarAposta(int valor) {
		aposta += valor;
	}
	
	public void setAposta(int aposta) {
	    this.aposta = aposta;
	}

	public int getAposta() {
		return aposta;
	}

	
	
	
	

}
