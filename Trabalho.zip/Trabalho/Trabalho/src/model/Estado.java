package model;

public enum Estado {
	APOSTA,
	JOGO,
	DEALER,
	FIM
}
