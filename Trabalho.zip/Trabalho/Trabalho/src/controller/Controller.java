package controller;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import model.Partida;
import view.JanelaInicial;
import view.JanelaBanca;
import view.JanelaMao;
import view.JanelaMaoJogador;

public class Controller {

	public Partida partida = new Partida();
	private JanelaInicial janelaInicial;
	private JanelaBanca janelaBanca;
	private JanelaMao maoDealer;
	private JanelaMaoJogador maoJogador;
	private JanelaMaoJogador maoJogadorSplit;

	private Rectangle[] botoesBounds;
	private String[] botoesLabels = { "EXIT", "DOUBLE", "SPLIT", "CLEAR", "DEAL", "HIT", "STAND", "SURRENDER" };
	private Rectangle[] fichaBounds;

	public Controller() {
		janelaInicial = new JanelaInicial();
		janelaInicial.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Point p = e.getPoint();
				if (janelaInicial.getBotaoNovoJogoBounds().contains(p)) {
					System.out.println("Botão 'Novo Jogo' clicado");
					iniciarJogo();
				} else if (janelaInicial.getBotaoContinuarBounds().contains(p)) {
					System.out.println("Botão 'Continuar Jogo' clicado");
				}
			}
		});
	}

	private void configurarBotoes() {
		botoesBounds = new Rectangle[] { new Rectangle(25, 600, 140, 50), // EXIT
				new Rectangle(220, 700, 140, 50), // DOUBLE
				new Rectangle(360, 700, 140, 50), // SPLIT
				new Rectangle(510, 700, 140, 50), // CLEAR
				new Rectangle(660, 700, 140, 50), // DEAL
				new Rectangle(840, 600, 140, 50), // HIT
				new Rectangle(840, 650, 140, 50), // STAND
				new Rectangle(840, 700, 140, 50) // SURRENDER
		};
	}

	private void iniciarJogo() {
		janelaInicial.dispose();
		janelaBanca = new JanelaBanca();
		configurarBotoes();
		fichaBounds = janelaBanca.getFichaBounds();

		janelaBanca.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Point p = e.getPoint();
				for (int i = 0; i < botoesBounds.length; i++) {
					if (botoesBounds[i].contains(p)) {
						System.out.println("Botão '" + botoesLabels[i] + "' clicado!");
						if (i == 0) {
							System.out.println("valido 0");

						} else if (i == 1 && partida.isApostou()) {
							System.out.println("valido 1");

						} else if (i == 2 && partida.isApostou()) {
							System.out.println("valido 2");

						} else if (i == 3 && !partida.isApostou()) {
							partida.devolveAposta();
							System.out.println("Aposta devolvida");

						} else if (i == 4 && !partida.isApostou()) {
							if (partida.validaAposta()) {
								System.out.println("Aposta validada");
								partida.setApostou(true);
								distribuirCartas();
							} else
								System.out.println("Aposta abaixo de 50");
						} else if (i == 5 && partida.isApostou()) {
							if (!partida.checkEstouro()) {
								partida.hit();
								distribuir1Carta();
							}

						} else if (i == 6 && partida.isApostou()) {
							System.out.println("valido 4");

						} else if (i == 7 && partida.isApostou()) {
							System.out.println("valido 5");

						}
					}

				}
				int aposta = 0;
				if (!partida.isApostou()) {
					for (int i = 0; i < fichaBounds.length; i++) {
						if (fichaBounds[i] != null && fichaBounds[i].contains(p)) {
							System.out.println("Ficha " + (i + 1) + " clicada!");
							if (i == 0) {
								if (e.getButton() == MouseEvent.BUTTON3 && partida.getMaoJogador().getAposta() > 0)
									aposta = -1;
								else if (e.getButton() == MouseEvent.BUTTON1)
									aposta = 1;
							}

							else if (i == 1) {
								if (e.getButton() == MouseEvent.BUTTON3 && partida.getMaoJogador().getAposta() > 0)
									aposta = -5;
								else if (e.getButton() == MouseEvent.BUTTON1)
									aposta = 5;
							} else if (i == 2) {
								if (e.getButton() == MouseEvent.BUTTON3 && partida.getMaoJogador().getAposta() > 0)
									aposta = -10;
								else if (e.getButton() == MouseEvent.BUTTON1)
									aposta = 10;
							} else if (i == 3) {
								if (e.getButton() == MouseEvent.BUTTON3 && partida.getMaoJogador().getAposta() > 0)
									aposta = -20;
								else if (e.getButton() == MouseEvent.BUTTON1)
									aposta = 20;
							} else if (i == 4) {
								if (e.getButton() == MouseEvent.BUTTON3 && partida.getMaoJogador().getAposta() > 0)
									aposta = -50;
								else if (e.getButton() == MouseEvent.BUTTON1)
									aposta = 50;
							} else if (i == 5) {
								if (e.getButton() == MouseEvent.BUTTON3 && partida.getMaoJogador().getAposta() > 0)
									aposta = -100;
								else if (e.getButton() == MouseEvent.BUTTON1)
									aposta = 100;
							}

							if (partida.checkAposta(aposta) == false)
								System.out.println("Dinheiro insuficiente");

						}

					}
					fazerApostas();
				}
			}
		});

		configurarJanelas();

	}

	private void configurarJanelas() {
		Dimension tela = Toolkit.getDefaultToolkit().getScreenSize();
		int startX = (tela.width - (1006 + 800)) / 2;
		int startY = (tela.height - 761) / 2;

		janelaBanca.setLocation(startX, startY);

		maoDealer = new JanelaMao(JanelaMao.TipoMao.DEALER);
		maoDealer.setLocation(startX + 1006, startY);

		maoJogador = new JanelaMaoJogador();
		maoJogador.setLocation(maoDealer.getX(), maoDealer.getY() + 250 + 10);

		maoJogadorSplit = new JanelaMaoJogador();
		maoJogadorSplit.setLocation(maoJogador.getX(), maoJogador.getY() + 250 + 10);

		janelaBanca.setVisible(true);
		maoDealer.setVisible(true);
		maoJogador.setVisible(true);
		maoJogadorSplit.setVisible(true);

	}

	private void fazerApostas() {
		// Carregar dinheiro
		maoJogador.atualizarDinheiro(partida.getDinheiro());
		maoJogador.atualizarAposta(partida.getMaoJogador().getAposta());
		maoJogador.repaint();

	}

	private void distribuirCartas() {
		// Distribui as cartas
		partida.distribuiCarta();
		partida.getMaoJogador().getLista_cartas();
		// Configurações para o Dealer
		maoDealer.atualizarPontos(partida.getMaos().getLast().calculaValorMao());
		maoDealer.receberCarta(partida.getMaos().getLast().getLista_cartas().getFirst().getNaipe());
		maoDealer.receberCarta(partida.getMaos().getLast().getLista_cartas().getLast().getNaipe());

		// Configurações para o Jogador Principal
		maoJogador.atualizarPontos(partida.getMaoJogador().calculaValorMao());
		maoJogador.receberCarta(partida.getMaoJogador().getLista_cartas().getFirst().getNaipe());
		maoJogador.receberCarta(partida.getMaoJogador().getLista_cartas().getLast().getNaipe());

	}

	private void distribuir1Carta() {
		// Configurações para o Jogador Principal
		maoJogador.atualizarPontos(partida.getMaoJogador().calculaValorMao());
		maoJogador.receberCarta(partida.getMaoJogador().getLista_cartas().getLast().getNaipe());

	}

	public static void main(String[] args) {
		new Controller();
	}
}