import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Rectangle2D;

import javax.swing.*;


public class JanelaInicial extends JFrame  {
	private int LARGURA = 800;
	private int ALTURA = 660;
	private Rectangle2D btNovaPartida;
	private Rectangle2D btCarregarPartida;
	
	public JanelaInicial() {
		// Configura o tamanho e posição da Janela
		int x= 0;
		int y= 10;
		setBounds(x,y,LARGURA,ALTURA);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		// Cria pseudo-botoes
		btNovaPartida = new Rectangle2D.Double(50, 50, 200, 100);       
		btCarregarPartida = new Rectangle2D.Double(50, 200, 200, 100);  
		
	}
	
	
	

	public Rectangle2D getBtNovaPartida() {
		return btNovaPartida;
	}




	public Rectangle2D getBtCarregarPartida() {
		return btCarregarPartida;
	}




	public void paint(Graphics g) {
		super.paintComponents(g);
		
		Graphics2D g2d = (Graphics2D) g;
		
		// Define a cor e desenha o retângulo
        g2d.setColor(Color.LIGHT_GRAY);
        g2d.fill(btNovaPartida);
        g2d.setColor(Color.BLACK);
        g2d.draw(btNovaPartida);
        
        g2d.setColor(Color.GREEN);
        g2d.fill(btCarregarPartida);
        g2d.setColor(Color.MAGENTA);
        g2d.draw(btCarregarPartida);
	}
	
	
}
