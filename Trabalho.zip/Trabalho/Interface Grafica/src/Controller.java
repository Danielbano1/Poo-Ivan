import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Controller{
	

	
	public static void main(String[] args) {
		JanelaInicial j = new JanelaInicial();
		j.setVisible(true);
		j.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				// Verifica se o clique ocorreu dentro do retângulo
				if (j.getBtNovaPartida().contains(e.getPoint())) {
					System.out.println("Nova partida");
					j.dispose();
				}
				if (j.getBtCarregarPartida().contains(e.getPoint())) {
					System.out.println("Carregar Partida");
				}
				
			}
		});
	}
}
