package view;

import javax.swing.*;

public class JanelaCarregamento extends JFrame {

    public JanelaCarregamento(String nome){

    }
}
