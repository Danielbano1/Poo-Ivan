package controller;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

import model.GerenciadorDeEstados;
import model.Partida;
import view.*;

public class Controller {

    public Partida partida = new Partida();
    private JanelaInicial janelaInicial;
    private JanelaBanca janelaBanca;
    private JanelaMao maoDealer;
    private JanelaMaoJogador maoJogador;
    private JanelaMaoJogador maoJogadorSplit;
    private TratadorDeClicks tratador;

    public Controller() {
        janelaInicial = new JanelaInicial();
        janelaInicial.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                Point p = e.getPoint();
                if (janelaInicial.getBotaoNovoJogoBounds().contains(p)) {
                    System.out.println("Botão 'Novo Jogo' clicado");
                    iniciarJogo();
                } else if (janelaInicial.getBotaoContinuarBounds().contains(p)) {
                    System.out.println("Botão 'Continuar Jogo' clicado");
                    telaCarregamento();
                }
            }
        });
    }

    private void telaCarregamento(){
        janelaInicial.dispose();
        new JanelaCarregamento("Carregamento de partida");

    }

    private void iniciarJogo() {
        janelaInicial.dispose();
        janelaBanca = new JanelaBanca();
        configurarJanelas();
        tratador = new TratadorDeClicks(this, janelaBanca);

    }

    private void configurarJanelas() {
        Dimension tela = Toolkit.getDefaultToolkit().getScreenSize();
        int startX = (tela.width - (1006 + 800)) / 2;
        int startY = (tela.height - 761) / 2;

        janelaBanca.setLocation(startX, startY);

        maoDealer = new JanelaMao(JanelaMao.TipoMao.DEALER);
        maoDealer.setLocation(startX + 1006, startY);

        maoJogador = new JanelaMaoJogador();
        maoJogador.setLocation(maoDealer.getX(), maoDealer.getY() + 250 + 10);

        maoJogadorSplit = new JanelaMaoJogador();
        maoJogadorSplit.setLocation(maoJogador.getX(), maoJogador.getY() + 250 + 10);

        janelaBanca.setVisible(true);
        maoDealer.setVisible(true);
        maoJogador.setVisible(true);
        maoJogadorSplit.setVisible(true);

    }

    void fazerApostas() {
        // Carregar dinheiro
        maoJogador.atualizarDinheiro(partida.getDinheiro());
        maoJogador.atualizarAposta(partida.getMaoJogador().getAposta());
        maoJogador.repaint();

    }

    void distribuirCartas() {
        // Distribui as cartas
        partida.distribuiCarta();
        // Configurações para o Dealer
        maoDealer.atualizarPontos(partida.getMaos().getLast().calculaValorMao());
        maoDealer.receberCarta(partida.getMaos().getLast().getLista_cartas().getFirst().getNaipe());
        maoDealer.receberCarta(partida.getMaos().getLast().getLista_cartas().getLast().getNaipe());

        // Configurações para o Jogador Principal
        maoJogador.atualizarPontos(partida.getMaoJogador().calculaValorMao());
        maoJogador.receberCarta(partida.getMaoJogador().getLista_cartas().getFirst().getNaipe());
        maoJogador.receberCarta(partida.getMaoJogador().getLista_cartas().getLast().getNaipe());

    }

    void distribuir1Carta() {
        // Configurações para o Jogador Principal
        maoJogador.atualizarPontos(partida.getMaoJogador().calculaValorMao());
        maoJogador.receberCarta(partida.getMaoJogador().getLista_cartas().getLast().getNaipe());

    }

    void jogaDealer() {
        partida.jogaDealer();
        // Configurações para o Dealer
        ArrayList<String> naipes = partida.retornaListaCartas();
        maoDealer.atualizarPontos(partida.getMaos().getLast().calculaValorMao());

        for (int i = naipes.size(); i > 2; i--)
            maoDealer.receberCarta(naipes.get(i - 1));

        partida.gerenciadorDeEstados.proxEstado();
    }

    void exibeResultados(){
        List<Integer> resultados = partida.checkStatusPartida();
        for (int i = 0; i < resultados.size(); i++){
            if (resultados.get(i) == 1) {
                janelaBanca.exibePlacar("Mao" + (i+1) + "venceu");
            } else if (resultados.get(i) == -1) {
                janelaBanca.exibePlacar( "Mao" + (i+1) + "perdeu");
            } else {
                janelaBanca.exibePlacar( "Empate");
            }
        }
    }

    public static void main(String[] args) {
        new Controller();
    }
}